# Release minification is disabled; add project-specific rules here if enabled later.
