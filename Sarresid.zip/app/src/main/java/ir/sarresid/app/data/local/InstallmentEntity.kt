package ir.sarresid.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.sarresid.app.domain.model.Installment

@Entity(
    tableName = "installments",
    indices = [Index(value = ["paidEpochDay"]), Index(value = ["dueEpochDay"])]
)
data class InstallmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val amount: Long,
    val dueEpochDay: Long,
    val paidEpochDay: Long? = null,
    val reminderFired: Boolean = false,
)

fun InstallmentEntity.toDomain(): Installment = Installment(
    id = id,
    title = title,
    amount = amount,
    dueEpochDay = dueEpochDay,
    paidEpochDay = paidEpochDay,
    reminderFired = reminderFired,
)

fun Installment.toEntity(): InstallmentEntity = InstallmentEntity(
    id = id,
    title = title,
    amount = amount,
    dueEpochDay = dueEpochDay,
    paidEpochDay = paidEpochDay,
    reminderFired = reminderFired,
)
