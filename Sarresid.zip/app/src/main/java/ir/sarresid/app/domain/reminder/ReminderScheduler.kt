package ir.sarresid.app.domain.reminder

import ir.sarresid.app.domain.model.Installment

/** Platform-independent contract; the Android implementation uses AlarmManager. */
interface ReminderScheduler {
    /** (Re)schedules the reminder for this installment, or cancels it if none is needed. */
    fun schedule(installment: Installment)

    fun cancel(installmentId: Long)
}
