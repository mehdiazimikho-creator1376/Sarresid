package ir.sarresid.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments WHERE paidEpochDay IS NULL ORDER BY dueEpochDay ASC, id ASC")
    fun observeUnpaid(): Flow<List<InstallmentEntity>>

    @Query("SELECT * FROM installments WHERE paidEpochDay IS NOT NULL ORDER BY paidEpochDay DESC, id DESC")
    fun observePaid(): Flow<List<InstallmentEntity>>

    @Query("SELECT * FROM installments WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): InstallmentEntity?

    @Query("SELECT * FROM installments WHERE paidEpochDay IS NULL AND reminderFired = 0")
    suspend fun getUnpaidWithPendingReminder(): List<InstallmentEntity>

    @Insert
    suspend fun insert(entity: InstallmentEntity): Long

    @Update
    suspend fun update(entity: InstallmentEntity)

    @Query("DELETE FROM installments WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE installments SET reminderFired = 1 WHERE id = :id")
    suspend fun markReminderFired(id: Long)
}
