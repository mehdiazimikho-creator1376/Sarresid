package ir.sarresid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.sarresid.app.core.PersianFormat
import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.ui.components.ConfirmDeleteDialog
import ir.sarresid.app.ui.components.HistoryCard
import ir.sarresid.app.ui.components.InstallmentCard
import ir.sarresid.app.ui.components.InstallmentFormDialog
import ir.sarresid.app.ui.components.JalaliDatePickerDialog
import java.time.LocalDate
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    notificationsEnabled: Boolean,
    onOpenNotificationSettings: () -> Unit,
) {
    val state by viewModel.uiState.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    var showAddDialog by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<Installment?>(null) }
    var payOnDateTarget by remember { mutableStateOf<Installment?>(null) }
    var paymentDateTarget by remember { mutableStateOf<Installment?>(null) }
    var deleteTarget by remember { mutableStateOf<Installment?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun payToday(item: Installment) {
        viewModel.recordPayment(item.id, LocalDate.now().toEpochDay())
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            val result = snackbarHostState.showSnackbar(
                message = "پرداخت «" + item.title + "» ثبت شد",
                actionLabel = "لغو",
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) {
                viewModel.undoPayment(item.id)
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = if (tab == 0) "سررسید" else "تاریخچه پرداخت‌ها",
                        fontWeight = FontWeight.Bold,
                    )
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
                    label = { Text("اقساط") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.CheckCircle, contentDescription = null) },
                    label = { Text("تاریخچه") },
                )
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { showAddDialog = true },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("قسط جدید") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (!notificationsEnabled) {
                NotificationsOffBanner(onOpenNotificationSettings)
            }
            if (tab == 0) {
                UpcomingList(
                    state = state,
                    onPay = { payToday(it) },
                    onPayOnOtherDate = { payOnDateTarget = it },
                    onEdit = { editTarget = it },
                    onDelete = { deleteTarget = it },
                )
            } else {
                HistoryList(
                    state = state,
                    onEditPaymentDate = { paymentDateTarget = it },
                    onEdit = { editTarget = it },
                    onUndo = { viewModel.undoPayment(it.id) },
                    onDelete = { deleteTarget = it },
                )
            }
        }
    }

    if (showAddDialog) {
        InstallmentFormDialog(
            initial = null,
            todayEpochDay = state.today,
            onDismiss = { showAddDialog = false },
            onConfirm = { title, amount, due ->
                viewModel.addInstallment(title, amount, due)
                showAddDialog = false
            },
        )
    }

    editTarget?.let { target ->
        InstallmentFormDialog(
            initial = target,
            todayEpochDay = state.today,
            onDismiss = { editTarget = null },
            onConfirm = { title, amount, due ->
                viewModel.updateInstallment(target.id, title, amount, due)
                editTarget = null
            },
        )
    }

    // Pay an unpaid installment on a date other than today (real payment date, never in the future).
    payOnDateTarget?.let { target ->
        JalaliDatePickerDialog(
            title = "تاریخ واقعی پرداخت",
            initialEpochDay = state.today,
            maxEpochDay = state.today,
            onDismiss = { payOnDateTarget = null },
            onConfirm = { day ->
                viewModel.recordPayment(target.id, day)
                payOnDateTarget = null
            },
        )
    }

    // Change the payment date of an already paid installment.
    paymentDateTarget?.let { target ->
        JalaliDatePickerDialog(
            title = "ویرایش تاریخ پرداخت",
            initialEpochDay = target.paidEpochDay ?: state.today,
            maxEpochDay = state.today,
            onDismiss = { paymentDateTarget = null },
            onConfirm = { day ->
                viewModel.recordPayment(target.id, day)
                paymentDateTarget = null
            },
        )
    }

    deleteTarget?.let { target ->
        ConfirmDeleteDialog(
            title = target.title,
            onDismiss = { deleteTarget = null },
            onConfirm = {
                viewModel.deleteInstallment(target.id)
                deleteTarget = null
            },
        )
    }
}

@Composable
private fun UpcomingList(
    state: UiState,
    onPay: (Installment) -> Unit,
    onPayOnOtherDate: (Installment) -> Unit,
    onEdit: (Installment) -> Unit,
    onDelete: (Installment) -> Unit,
) {
    if (state.loaded && state.unpaid.isEmpty()) {
        EmptyState(
            title = "قسطی ثبت نشده است",
            hint = "با دکمه «قسط جدید» اولین قسط را اضافه کنید.",
        )
        return
    }
    val overdue = state.unpaid.filter { it.dueEpochDay < state.today }
    val upcoming = state.unpaid.filter { it.dueEpochDay >= state.today }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (overdue.isNotEmpty()) {
            item(key = "header_overdue") {
                SectionHeader("سررسیدشده", overdue.size, MaterialTheme.colorScheme.error)
            }
            items(overdue, key = { it.id }) { item ->
                InstallmentCard(
                    item = item,
                    todayEpochDay = state.today,
                    onPay = { onPay(item) },
                    onPayOnOtherDate = { onPayOnOtherDate(item) },
                    onEdit = { onEdit(item) },
                    onDelete = { onDelete(item) },
                )
            }
        }
        if (upcoming.isNotEmpty()) {
            item(key = "header_upcoming") {
                SectionHeader("پیش‌رو", upcoming.size, MaterialTheme.colorScheme.primary)
            }
            items(upcoming, key = { it.id }) { item ->
                InstallmentCard(
                    item = item,
                    todayEpochDay = state.today,
                    onPay = { onPay(item) },
                    onPayOnOtherDate = { onPayOnOtherDate(item) },
                    onEdit = { onEdit(item) },
                    onDelete = { onDelete(item) },
                )
            }
        }
    }
}

@Composable
private fun HistoryList(
    state: UiState,
    onEditPaymentDate: (Installment) -> Unit,
    onEdit: (Installment) -> Unit,
    onUndo: (Installment) -> Unit,
    onDelete: (Installment) -> Unit,
) {
    if (state.loaded && state.paid.isEmpty()) {
        EmptyState(
            title = "هنوز پرداختی ثبت نشده است",
            hint = "با زدن «پرداخت شد» روی هر قسط، اینجا ثبت می‌شود.",
        )
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(state.paid, key = { it.id }) { item ->
            HistoryCard(
                item = item,
                onEditPaymentDate = { onEditPaymentDate(item) },
                onEdit = { onEdit(item) },
                onUndo = { onUndo(item) },
                onDelete = { onDelete(item) },
            )
        }
    }
}

@Composable
private fun SectionHeader(text: String, count: Int, color: Color) {
    Row(
        modifier = Modifier.padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall,
            color = color,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = PersianFormat.number(count.toLong()),
            style = MaterialTheme.typography.labelMedium,
            color = color,
        )
    }
}

@Composable
private fun EmptyState(title: String, hint: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = hint,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun NotificationsOffBanner(onOpenSettings: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, top = 8.dp, end = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "اعلان‌ها خاموش است؛ یادآوری سررسید نمایش داده نمی‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onOpenSettings) { Text("فعال‌سازی") }
        }
    }
}
