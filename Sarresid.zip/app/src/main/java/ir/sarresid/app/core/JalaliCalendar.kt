package ir.sarresid.app.core

import java.time.LocalDate

/** A date in the Jalali (Persian / Solar Hijri) calendar. Month is 1..12. */
data class JalaliDate(val year: Int, val month: Int, val day: Int) : Comparable<JalaliDate> {
    override fun compareTo(other: JalaliDate): Int {
        if (year != other.year) return year.compareTo(other.year)
        if (month != other.month) return month.compareTo(other.month)
        return day.compareTo(other.day)
    }
}

/**
 * Real Jalali calendar conversion (arithmetic algorithm of Behrooz Birashk / jalaali-js,
 * valid for Jalali years -61..3177 and matching the official Iranian calendar for the modern era).
 *
 * All app dates are stored as Gregorian *epoch days* (days since 1970-01-01), which makes them
 * independent of time zones and DST.
 */
object JalaliCalendar {
    const val MIN_YEAR = 1300
    const val MAX_YEAR = 1700

    private val breaks = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
        1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    private class Cal(val leap: Int, val gy: Int, val march: Int)

    private fun cal(jy: Int): Cal {
        require(jy >= breaks[0] && jy < breaks[breaks.size - 1]) { "Invalid Jalali year $jy" }
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until breaks.size) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + (jump % 33) / 4
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + ((n % 33) + 3) / 4
        if (jump % 33 == 4 && jump - n == 4) leapJ += 1
        val leapG = (gy / 4) - (((gy / 100) + 1) * 3 / 4) - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = ((n + 1) % 33 - 1) % 4
        if (leap == -1) leap = 4
        return Cal(leap, gy, march)
    }

    fun isLeapYear(year: Int): Boolean = cal(year).leap == 0

    fun daysInMonth(year: Int, month: Int): Int = when (month) {
        in 1..6 -> 31
        in 7..11 -> 30
        12 -> if (isLeapYear(year)) 30 else 29
        else -> throw IllegalArgumentException("Invalid Jalali month $month")
    }

    fun isValid(year: Int, month: Int, day: Int): Boolean {
        if (year < MIN_YEAR || year > MAX_YEAR) return false
        if (month < 1 || month > 12) return false
        return day >= 1 && day <= daysInMonth(year, month)
    }

    /** Jalali date -> Gregorian epoch day. */
    fun toEpochDay(year: Int, month: Int, day: Int): Long {
        val r = cal(year)
        val firstOfFarvardin = LocalDate.of(r.gy, 3, r.march).toEpochDay()
        return firstOfFarvardin + (month - 1) * 31 - (month / 7) * (month - 7) + day - 1
    }

    fun toEpochDay(date: JalaliDate): Long = toEpochDay(date.year, date.month, date.day)

    /** Gregorian epoch day -> Jalali date. */
    fun fromEpochDay(epochDay: Long): JalaliDate {
        val gy = LocalDate.ofEpochDay(epochDay).year
        var jy = gy - 621
        val r = cal(jy)
        val firstOfFarvardin = LocalDate.of(r.gy, 3, r.march).toEpochDay()
        var k = (epochDay - firstOfFarvardin).toInt()
        if (k >= 0) {
            if (k <= 185) {
                return JalaliDate(jy, 1 + k / 31, k % 31 + 1)
            }
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        return JalaliDate(jy, 7 + k / 30, k % 30 + 1)
    }

    /** 0 = Saturday (شنبه) ... 6 = Friday (جمعه), the Persian week order. */
    fun dayOfWeekIndex(epochDay: Long): Int {
        val isoDow = LocalDate.ofEpochDay(epochDay).dayOfWeek.value // Mon=1 .. Sun=7
        return (isoDow + 1) % 7
    }
}
