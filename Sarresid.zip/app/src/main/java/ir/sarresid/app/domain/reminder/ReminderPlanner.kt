package ir.sarresid.app.domain.reminder

import ir.sarresid.app.core.PersianFormat
import ir.sarresid.app.domain.model.Installment
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Pure logic deciding when a reminder should fire (kept free of Android for testability). */
object ReminderPlanner {
    /** The reminder is shown at this local hour on the day before the due date. */
    const val REMINDER_HOUR = 9

    const val IMMEDIATE_DELAY_MILLIS = 5_000L

    /**
     * Returns the epoch millis at which to fire the reminder, or null when none is needed
     * (already paid, already reminded, or the due date has passed).
     *
     * If the planned time (09:00 the day before the due date) is already in the past but the
     * due date is still today or later, the reminder fires almost immediately.
     */
    fun triggerAtMillis(installment: Installment, nowMillis: Long, zone: ZoneId): Long? {
        if (installment.isPaid || installment.reminderFired) return null
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate().toEpochDay()
        if (installment.dueEpochDay < today) return null
        val planned = LocalDate.ofEpochDay(installment.dueEpochDay - 1)
            .atTime(REMINDER_HOUR, 0)
            .atZone(zone)
            .toInstant()
            .toEpochMilli()
        return if (planned > nowMillis) planned else nowMillis + IMMEDIATE_DELAY_MILLIS
    }
}

object ReminderMessages {
    const val TITLE = "یادآوری سررسید قسط"

    fun text(installment: Installment, todayEpochDay: Long): String {
        val days = installment.dueEpochDay - todayEpochDay
        val whenText = when {
            days == 0L -> "امروز سررسید است"
            days < 0L -> "سررسید آن گذشته است"
            days == 1L -> "فردا سررسید است"
            else -> PersianFormat.number(days) + " روز دیگر سررسید است"
        }
        return "«" + installment.title + "» به مبلغ " +
            PersianFormat.amount(installment.amount) + " تومان — " + whenText
    }
}
