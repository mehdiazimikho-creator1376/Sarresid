package ir.sarresid.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.sarresid.app.SarresidApplication
import kotlinx.coroutines.launch

/**
 * AlarmManager alarms do not survive a reboot. This receiver re-creates every pending reminder
 * after boot, after an app update, and after clock or time zone changes.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val container = (context.applicationContext as SarresidApplication).container
                val pending = goAsync()
                container.appScope.launch {
                    try {
                        container.useCases.rescheduleAll()
                    } finally {
                        pending.finish()
                    }
                }
            }
            else -> Unit
        }
    }
}
