package ir.sarresid.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.usecase.UseCases
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(
    val unpaid: List<Installment> = emptyList(),
    val paid: List<Installment> = emptyList(),
    val today: Long = LocalDate.now().toEpochDay(),
    val loaded: Boolean = false,
)

class MainViewModel(private val useCases: UseCases) : ViewModel() {

    private val today = MutableStateFlow(LocalDate.now().toEpochDay())

    val uiState: StateFlow<UiState> = combine(
        useCases.observe.unpaid(),
        useCases.observe.paid(),
        today,
    ) { unpaid, paid, day ->
        UiState(unpaid = unpaid, paid = paid, today = day, loaded = true)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    /** Call when the app comes to the foreground so "today" is correct after midnight. */
    fun refreshToday() {
        today.value = LocalDate.now().toEpochDay()
    }

    fun addInstallment(title: String, amount: Long, dueEpochDay: Long) {
        viewModelScope.launch { useCases.add(title, amount, dueEpochDay) }
    }

    fun updateInstallment(id: Long, title: String, amount: Long, dueEpochDay: Long) {
        viewModelScope.launch { useCases.update(id, title, amount, dueEpochDay) }
    }

    fun recordPayment(id: Long, paidEpochDay: Long) {
        viewModelScope.launch { useCases.recordPayment(id, paidEpochDay) }
    }

    fun undoPayment(id: Long) {
        viewModelScope.launch { useCases.undoPayment(id) }
    }

    fun deleteInstallment(id: Long) {
        viewModelScope.launch { useCases.delete(id) }
    }

    companion object {
        fun factory(useCases: UseCases): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(useCases) as T
        }
    }
}
