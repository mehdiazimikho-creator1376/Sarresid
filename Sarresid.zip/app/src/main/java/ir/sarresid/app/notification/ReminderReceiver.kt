package ir.sarresid.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.sarresid.app.SarresidApplication
import java.time.LocalDate
import kotlinx.coroutines.launch

/** Receives the alarm and shows the "installment due tomorrow" notification. */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmReminderScheduler.ACTION_REMINDER) return
        val id = intent.getLongExtra(AlarmReminderScheduler.EXTRA_INSTALLMENT_ID, -1L)
        if (id < 0L) return

        val container = (context.applicationContext as SarresidApplication).container
        val pending = goAsync()
        container.appScope.launch {
            try {
                val installment = container.useCases.prepareReminder(id)
                if (installment != null) {
                    val shown = container.notifier.show(installment, LocalDate.now().toEpochDay())
                    if (shown) container.useCases.markReminderFired(id)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
