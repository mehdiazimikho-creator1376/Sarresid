package ir.sarresid.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.sarresid.app.core.PersianFormat
import ir.sarresid.app.domain.model.Installment

/** Add (initial == null) or edit an installment: title, amount (Toman) and Jalali due date. */
@Composable
fun InstallmentFormDialog(
    initial: Installment?,
    todayEpochDay: Long,
    onDismiss: () -> Unit,
    onConfirm: (title: String, amount: Long, dueEpochDay: Long) -> Unit,
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember {
        mutableStateOf(if (initial != null) PersianFormat.number(initial.amount) else "")
    }
    var dueEpochDay by remember { mutableLongStateOf(initial?.dueEpochDay ?: todayEpochDay) }
    var showDatePicker by remember { mutableStateOf(false) }
    var triedToSave by remember { mutableStateOf(false) }

    val parsedAmount = PersianFormat.parseAmount(amountText)
    val titleValid = title.isNotBlank()
    val amountValid = parsedAmount != null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "قسط جدید" else "ویرایش قسط") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان قسط") },
                    singleLine = true,
                    isError = triedToSave && !titleValid,
                    supportingText = {
                        if (triedToSave && !titleValid) Text("عنوان را وارد کنید")
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("مبلغ (تومان)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = triedToSave && !amountValid,
                    supportingText = {
                        when {
                            parsedAmount != null -> Text(PersianFormat.amount(parsedAmount) + " تومان")
                            triedToSave -> Text("مبلغ معتبر وارد کنید")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.DateRange, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("سررسید: " + PersianFormat.dateWithWeekday(dueEpochDay))
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    triedToSave = true
                    if (titleValid && parsedAmount != null) {
                        onConfirm(title.trim(), parsedAmount, dueEpochDay)
                    }
                },
            ) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        },
    )

    if (showDatePicker) {
        JalaliDatePickerDialog(
            title = "تاریخ سررسید",
            initialEpochDay = dueEpochDay,
            onDismiss = { showDatePicker = false },
            onConfirm = {
                dueEpochDay = it
                showDatePicker = false
            },
        )
    }
}
