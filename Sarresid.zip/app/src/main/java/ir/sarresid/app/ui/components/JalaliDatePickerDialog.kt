package ir.sarresid.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.sarresid.app.core.JalaliCalendar
import ir.sarresid.app.core.PersianFormat
import java.time.LocalDate

/**
 * Real Jalali (Persian) date picker. Weeks start on Saturday; with the app's RTL layout
 * Saturday is the right-most column. All values are Gregorian epoch days.
 */
@Composable
fun JalaliDatePickerDialog(
    title: String,
    initialEpochDay: Long,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit,
    minEpochDay: Long? = null,
    maxEpochDay: Long? = null,
) {
    val initial = remember(initialEpochDay) { JalaliCalendar.fromEpochDay(initialEpochDay) }
    var year by remember { mutableIntStateOf(initial.year) }
    var month by remember { mutableIntStateOf(initial.month) }
    var selected by remember { mutableLongStateOf(initialEpochDay) }
    val todayEpoch = remember { LocalDate.now().toEpochDay() }

    fun shiftMonth(delta: Int) {
        var y = year
        var m = month + delta
        if (m > 12) {
            m = 1
            y += 1
        } else if (m < 1) {
            m = 12
            y -= 1
        }
        if (y >= JalaliCalendar.MIN_YEAR && y <= JalaliCalendar.MAX_YEAR) {
            year = y
            month = m
        }
    }

    fun shiftYear(delta: Int) {
        val y = year + delta
        if (y >= JalaliCalendar.MIN_YEAR && y <= JalaliCalendar.MAX_YEAR) year = y
    }

    val firstEpoch = JalaliCalendar.toEpochDay(year, month, 1)
    val offset = JalaliCalendar.dayOfWeekIndex(firstEpoch)
    val daysInMonth = JalaliCalendar.daysInMonth(year, month)
    val rows = (offset + daysInMonth + 6) / 7

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = PersianFormat.dateWithWeekday(selected),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(8.dp))

                // Month navigation. In RTL the first child is on the right (previous month).
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { shiftMonth(-1) }) {
                        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "ماه قبل")
                    }
                    Text(
                        text = PersianFormat.monthNames[month - 1],
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    IconButton(onClick = { shiftMonth(1) }) {
                        Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "ماه بعد")
                    }
                }

                // Year navigation.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { shiftYear(-1) }) {
                        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "سال قبل")
                    }
                    Text(
                        text = PersianFormat.number(year.toLong()),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleSmall,
                    )
                    IconButton(onClick = { shiftYear(1) }) {
                        Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "سال بعد")
                    }
                }

                Spacer(Modifier.height(4.dp))

                // Weekday header (Saturday first).
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = PersianFormat.weekdayShort[c],
                                style = MaterialTheme.typography.labelMedium,
                                color = if (c == 6) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                // Day grid.
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    for (r in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (c in 0 until 7) {
                                val dayNumber = r * 7 + c - offset + 1
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (dayNumber in 1..daysInMonth) {
                                        val epoch = firstEpoch + (dayNumber - 1)
                                        val allowed = (minEpochDay == null || epoch >= minEpochDay) &&
                                            (maxEpochDay == null || epoch <= maxEpochDay)
                                        DayCell(
                                            label = PersianFormat.number(dayNumber.toLong()),
                                            isSelected = epoch == selected,
                                            isToday = epoch == todayEpoch,
                                            isFriday = c == 6,
                                            enabled = allowed,
                                            onClick = { selected = epoch },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selected) }) { Text("تأیید") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        },
    )
}

@Composable
private fun DayCell(
    label: String,
    isSelected: Boolean,
    isToday: Boolean,
    isFriday: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val background = if (isSelected) scheme.primary else Color.Transparent
    val textColor = when {
        isSelected -> scheme.onPrimary
        !enabled -> scheme.onSurface.copy(alpha = 0.3f)
        isFriday -> scheme.error
        else -> scheme.onSurface
    }
    var cellModifier = Modifier
        .padding(2.dp)
        .fillMaxWidth()
        .aspectRatio(1f)
        .clip(CircleShape)
        .background(background)
    if (isToday && !isSelected) {
        cellModifier = cellModifier.border(1.dp, scheme.primary, CircleShape)
    }
    Box(
        modifier = cellModifier.clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = textColor,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
        )
    }
}
