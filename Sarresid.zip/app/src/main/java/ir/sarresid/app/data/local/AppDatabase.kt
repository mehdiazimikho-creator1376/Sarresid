package ir.sarresid.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [InstallmentEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun installmentDao(): InstallmentDao
}
