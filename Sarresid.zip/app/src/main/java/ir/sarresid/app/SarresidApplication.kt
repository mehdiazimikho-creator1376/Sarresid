package ir.sarresid.app

import android.app.Application
import ir.sarresid.app.di.AppContainer
import kotlinx.coroutines.launch

class SarresidApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.notifier.ensureChannel()
        // Make sure every pending reminder has an alarm (cheap and idempotent).
        container.appScope.launch { container.useCases.rescheduleAll() }
    }
}
