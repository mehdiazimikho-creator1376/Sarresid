package ir.sarresid.app.domain.usecase

import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.reminder.ReminderScheduler
import ir.sarresid.app.domain.repository.InstallmentRepository
import kotlinx.coroutines.flow.Flow

class ObserveInstallments(private val repository: InstallmentRepository) {
    fun unpaid(): Flow<List<Installment>> = repository.observeUnpaid()
    fun paid(): Flow<List<Installment>> = repository.observePaid()
}

class AddInstallment(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke(title: String, amount: Long, dueEpochDay: Long): Long {
        val id = repository.insert(
            Installment(title = title.trim(), amount = amount, dueEpochDay = dueEpochDay)
        )
        repository.getById(id)?.let { scheduler.schedule(it) }
        return id
    }
}

class UpdateInstallment(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke(id: Long, title: String, amount: Long, dueEpochDay: Long) {
        val old = repository.getById(id) ?: return
        val dueChanged = old.dueEpochDay != dueEpochDay
        val updated = old.copy(
            title = title.trim(),
            amount = amount,
            dueEpochDay = dueEpochDay,
            reminderFired = if (dueChanged) false else old.reminderFired,
        )
        repository.update(updated)
        scheduler.schedule(updated) // cancels automatically when the item is paid
    }
}

/** Records (or changes) the real payment date. Used for one-tap payment and for editing the date. */
class RecordPayment(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke(id: Long, paidEpochDay: Long) {
        val old = repository.getById(id) ?: return
        repository.update(old.copy(paidEpochDay = paidEpochDay))
        scheduler.cancel(id)
    }
}

/** Moves a paid installment back to the unpaid list. */
class UndoPayment(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke(id: Long) {
        val old = repository.getById(id) ?: return
        val updated = old.copy(paidEpochDay = null, reminderFired = false)
        repository.update(updated)
        scheduler.schedule(updated)
    }
}

class DeleteInstallment(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke(id: Long) {
        scheduler.cancel(id)
        repository.delete(id)
    }
}

/** Re-creates every pending alarm (after reboot, app update, clock or time zone change). */
class RescheduleAllReminders(
    private val repository: InstallmentRepository,
    private val scheduler: ReminderScheduler,
) {
    suspend operator fun invoke() {
        for (installment in repository.getUnpaidWithPendingReminder()) {
            scheduler.schedule(installment)
        }
    }
}

/** Returns the installment to notify about, or null when nothing should be shown. */
class PrepareReminder(private val repository: InstallmentRepository) {
    suspend operator fun invoke(id: Long): Installment? {
        val installment = repository.getById(id) ?: return null
        if (installment.isPaid || installment.reminderFired) return null
        return installment
    }
}

class MarkReminderFired(private val repository: InstallmentRepository) {
    suspend operator fun invoke(id: Long) = repository.markReminderFired(id)
}

class UseCases(
    val observe: ObserveInstallments,
    val add: AddInstallment,
    val update: UpdateInstallment,
    val recordPayment: RecordPayment,
    val undoPayment: UndoPayment,
    val delete: DeleteInstallment,
    val rescheduleAll: RescheduleAllReminders,
    val prepareReminder: PrepareReminder,
    val markReminderFired: MarkReminderFired,
) {
    companion object {
        fun create(repository: InstallmentRepository, scheduler: ReminderScheduler) = UseCases(
            observe = ObserveInstallments(repository),
            add = AddInstallment(repository, scheduler),
            update = UpdateInstallment(repository, scheduler),
            recordPayment = RecordPayment(repository, scheduler),
            undoPayment = UndoPayment(repository, scheduler),
            delete = DeleteInstallment(repository, scheduler),
            rescheduleAll = RescheduleAllReminders(repository, scheduler),
            prepareReminder = PrepareReminder(repository),
            markReminderFired = MarkReminderFired(repository),
        )
    }
}
