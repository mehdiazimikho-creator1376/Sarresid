package ir.sarresid.app.data.repository

import ir.sarresid.app.data.local.InstallmentDao
import ir.sarresid.app.data.local.toDomain
import ir.sarresid.app.data.local.toEntity
import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.repository.InstallmentRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RoomInstallmentRepository(private val dao: InstallmentDao) : InstallmentRepository {

    override fun observeUnpaid(): Flow<List<Installment>> =
        dao.observeUnpaid().map { list -> list.map { it.toDomain() } }

    override fun observePaid(): Flow<List<Installment>> =
        dao.observePaid().map { list -> list.map { it.toDomain() } }

    override suspend fun getById(id: Long): Installment? = dao.getById(id)?.toDomain()

    override suspend fun getUnpaidWithPendingReminder(): List<Installment> =
        dao.getUnpaidWithPendingReminder().map { it.toDomain() }

    override suspend fun insert(installment: Installment): Long =
        dao.insert(installment.copy(id = 0L).toEntity())

    override suspend fun update(installment: Installment) {
        dao.update(installment.toEntity())
    }

    override suspend fun delete(id: Long) {
        dao.deleteById(id)
    }

    override suspend fun markReminderFired(id: Long) {
        dao.markReminderFired(id)
    }
}
