package ir.sarresid.app.domain.repository

import ir.sarresid.app.domain.model.Installment
import kotlinx.coroutines.flow.Flow

interface InstallmentRepository {
    /** Unpaid installments ordered by due date (soonest first). */
    fun observeUnpaid(): Flow<List<Installment>>

    /** Paid installments ordered by payment date (latest first). */
    fun observePaid(): Flow<List<Installment>>

    suspend fun getById(id: Long): Installment?

    /** Unpaid installments whose reminder has not been shown yet. */
    suspend fun getUnpaidWithPendingReminder(): List<Installment>

    suspend fun insert(installment: Installment): Long

    suspend fun update(installment: Installment)

    suspend fun delete(id: Long)

    suspend fun markReminderFired(id: Long)
}
