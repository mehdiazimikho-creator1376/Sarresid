package ir.sarresid.app.core

/** Persian digits, money and date formatting, plus tolerant amount parsing. */
object PersianFormat {
    val monthNames: List<String> = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    /** Index 0 = Saturday, matching [JalaliCalendar.dayOfWeekIndex]. */
    val weekdayNames: List<String> = listOf(
        "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"
    )

    val weekdayShort: List<String> = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

    private const val THOUSANDS_SEPARATOR = '٬'

    /** Replace Latin digits with Persian digits. */
    fun digits(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            if (c in '0'..'9') sb.append('۰' + (c - '0')) else sb.append(c)
        }
        return sb.toString()
    }

    /** Replace Persian (۰-۹) and Arabic-Indic (٠-٩) digits with Latin digits. */
    fun toLatinDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            when (c) {
                in '۰'..'۹' -> sb.append('0' + (c - '۰'))
                in '٠'..'٩' -> sb.append('0' + (c - '٠'))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun number(n: Long): String = digits(n.toString())

    /** 1250000 -> ۱٬۲۵۰٬۰۰۰ */
    fun amount(n: Long): String {
        val s = n.toString()
        val negative = s.startsWith("-")
        val body = if (negative) s.substring(1) else s
        val sb = StringBuilder()
        for (i in body.indices) {
            if (i > 0 && (body.length - i) % 3 == 0) sb.append(THOUSANDS_SEPARATOR)
            sb.append(body[i])
        }
        return digits((if (negative) "-" else "") + sb.toString())
    }

    /**
     * Parses a user-typed amount. Accepts Persian/Arabic/Latin digits and common
     * thousands separators. Returns null for empty, non-numeric, zero or absurdly large input.
     */
    fun parseAmount(input: String): Long? {
        val latin = toLatinDigits(input)
        val cleaned = latin.filterNot {
            it == ',' || it == '٬' || it == '،' || it == ' ' ||
                it == ' ' || it == '‌' || it == '‎' || it == '‏'
        }
        if (cleaned.isEmpty() || cleaned.length > 15) return null
        if (!cleaned.all { it in '0'..'9' }) return null
        val value = cleaned.toLongOrNull() ?: return null
        return if (value > 0L) value else null
    }

    /** ۱۷ آبان ۱۴۰۵ */
    fun date(epochDay: Long): String {
        val j = JalaliCalendar.fromEpochDay(epochDay)
        return number(j.day.toLong()) + " " + monthNames[j.month - 1] + " " + number(j.year.toLong())
    }

    /** یکشنبه ۱۷ آبان ۱۴۰۵ */
    fun dateWithWeekday(epochDay: Long): String =
        weekdayNames[JalaliCalendar.dayOfWeekIndex(epochDay)] + " " + date(epochDay)

    /** ۱۴۰۵/۰۸/۱۷ */
    fun dateNumeric(epochDay: Long): String {
        val j = JalaliCalendar.fromEpochDay(epochDay)
        val text = j.year.toString().padStart(4, '0') + "/" +
            j.month.toString().padStart(2, '0') + "/" +
            j.day.toString().padStart(2, '0')
        return digits(text)
    }

    /** Relative description of a due date versus today. */
    fun relativeDays(dueEpochDay: Long, todayEpochDay: Long): String {
        val d = dueEpochDay - todayEpochDay
        return when {
            d == 0L -> "امروز"
            d == 1L -> "فردا"
            d == -1L -> "دیروز"
            d > 1L -> number(d) + " روز دیگر"
            else -> number(-d) + " روز گذشته"
        }
    }
}
