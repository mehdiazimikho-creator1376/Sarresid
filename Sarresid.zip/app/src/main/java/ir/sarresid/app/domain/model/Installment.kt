package ir.sarresid.app.domain.model

/**
 * One installment. Dates are Gregorian epoch days (days since 1970-01-01).
 * An installment is "paid" once [paidEpochDay] is set; the paid list is the payment history.
 */
data class Installment(
    val id: Long = 0L,
    val title: String,
    val amount: Long,
    val dueEpochDay: Long,
    val paidEpochDay: Long? = null,
    val reminderFired: Boolean = false,
) {
    val isPaid: Boolean get() = paidEpochDay != null
}
