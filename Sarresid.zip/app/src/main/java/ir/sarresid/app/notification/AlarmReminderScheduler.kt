package ir.sarresid.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.reminder.ReminderPlanner
import ir.sarresid.app.domain.reminder.ReminderScheduler
import java.time.ZoneId

/**
 * Schedules one alarm per installment with AlarmManager. [AlarmManager.setAndAllowWhileIdle]
 * needs no special permission and still fires in Doze (it may be delayed by a few minutes).
 * Alarms are lost on reboot, so [BootReceiver] re-creates them.
 */
class AlarmReminderScheduler(context: Context) : ReminderScheduler {

    private val appContext = context.applicationContext
    private val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    override fun schedule(installment: Installment) {
        val triggerAt = ReminderPlanner.triggerAtMillis(
            installment = installment,
            nowMillis = System.currentTimeMillis(),
            zone = ZoneId.systemDefault(),
        )
        if (triggerAt == null) {
            cancel(installment.id)
            return
        }
        val pendingIntent = pendingIntent(installment.id, create = true) ?: return
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
    }

    override fun cancel(installmentId: Long) {
        val pendingIntent = pendingIntent(installmentId, create = false) ?: return
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    private fun pendingIntent(installmentId: Long, create: Boolean): PendingIntent? {
        val intent = Intent(appContext, ReminderReceiver::class.java).apply {
            action = ACTION_REMINDER
            putExtra(EXTRA_INSTALLMENT_ID, installmentId)
        }
        val mode = if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        return PendingIntent.getBroadcast(
            appContext,
            installmentId.toInt(),
            intent,
            mode or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        const val ACTION_REMINDER = "ir.sarresid.app.action.REMINDER"
        const val EXTRA_INSTALLMENT_ID = "installment_id"
    }
}
