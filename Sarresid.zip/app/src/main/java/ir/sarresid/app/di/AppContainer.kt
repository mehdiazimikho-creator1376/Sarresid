package ir.sarresid.app.di

import android.content.Context
import androidx.room.Room
import ir.sarresid.app.data.local.AppDatabase
import ir.sarresid.app.data.repository.RoomInstallmentRepository
import ir.sarresid.app.domain.reminder.ReminderScheduler
import ir.sarresid.app.domain.repository.InstallmentRepository
import ir.sarresid.app.domain.usecase.UseCases
import ir.sarresid.app.notification.AlarmReminderScheduler
import ir.sarresid.app.notification.ReminderNotifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Tiny manual dependency container (no DI framework needed for an app this size). */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    /** Process-wide scope for work started from broadcast receivers. */
    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val database: AppDatabase =
        Room.databaseBuilder(appContext, AppDatabase::class.java, "sarresid.db").build()

    val repository: InstallmentRepository = RoomInstallmentRepository(database.installmentDao())
    val scheduler: ReminderScheduler = AlarmReminderScheduler(appContext)
    val notifier: ReminderNotifier = ReminderNotifier(appContext)
    val useCases: UseCases = UseCases.create(repository, scheduler)
}
