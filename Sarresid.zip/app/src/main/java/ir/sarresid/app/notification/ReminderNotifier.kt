package ir.sarresid.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.sarresid.app.MainActivity
import ir.sarresid.app.R
import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.reminder.ReminderMessages

class ReminderNotifier(context: Context) {

    private val appContext = context.applicationContext

    fun ensureChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "یادآوری اقساط",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "یادآوری یک روز قبل از سررسید اقساط"
        }
        val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    /** Returns true if the notification was handed to the system. */
    fun show(installment: Installment, todayEpochDay: Long): Boolean {
        val manager = NotificationManagerCompat.from(appContext)
        if (!manager.areNotificationsEnabled()) return false

        val text = ReminderMessages.text(installment, todayEpochDay)
        val openApp = Intent(appContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            appContext,
            0,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ReminderMessages.TITLE)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        return try {
            manager.notify(installment.id.toInt(), notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    companion object {
        const val CHANNEL_ID = "installment_reminders"
    }
}
