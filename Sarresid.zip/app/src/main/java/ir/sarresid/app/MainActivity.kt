package ir.sarresid.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import ir.sarresid.app.ui.MainScreen
import ir.sarresid.app.ui.MainViewModel
import ir.sarresid.app.ui.theme.SarresidTheme

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MainViewModel
    private var notificationsEnabled by mutableStateOf(true)

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            notificationsEnabled = NotificationManagerCompat.from(this).areNotificationsEnabled()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = (application as SarresidApplication).container
        viewModel = ViewModelProvider(this, MainViewModel.factory(container.useCases))[MainViewModel::class.java]

        requestNotificationPermissionIfNeeded()

        setContent {
            SarresidTheme {
                MainScreen(
                    viewModel = viewModel,
                    notificationsEnabled = notificationsEnabled,
                    onOpenNotificationSettings = { openNotificationSettings() },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshToday()
        notificationsEnabled = NotificationManagerCompat.from(this).areNotificationsEnabled()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        }
        startActivity(intent)
    }
}
