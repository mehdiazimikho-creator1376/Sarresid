package ir.sarresid.app

import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.reminder.ReminderScheduler
import ir.sarresid.app.domain.repository.InstallmentRepository
import ir.sarresid.app.domain.usecase.UseCases
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeRepository : InstallmentRepository {
    val items = MutableStateFlow<List<Installment>>(emptyList())
    private var nextId = 1L

    override fun observeUnpaid(): Flow<List<Installment>> =
        items.map { list -> list.filter { it.paidEpochDay == null }.sortedWith(compareBy({ it.dueEpochDay }, { it.id })) }

    override fun observePaid(): Flow<List<Installment>> =
        items.map { list -> list.filter { it.paidEpochDay != null }.sortedByDescending { it.paidEpochDay } }

    override suspend fun getById(id: Long): Installment? = items.value.firstOrNull { it.id == id }

    override suspend fun getUnpaidWithPendingReminder(): List<Installment> =
        items.value.filter { it.paidEpochDay == null && !it.reminderFired }

    override suspend fun insert(installment: Installment): Long {
        val id = nextId++
        items.value = items.value + installment.copy(id = id)
        return id
    }

    override suspend fun update(installment: Installment) {
        items.value = items.value.map { if (it.id == installment.id) installment else it }
    }

    override suspend fun delete(id: Long) {
        items.value = items.value.filter { it.id != id }
    }

    override suspend fun markReminderFired(id: Long) {
        items.value = items.value.map { if (it.id == id) it.copy(reminderFired = true) else it }
    }
}

private class FakeScheduler : ReminderScheduler {
    val scheduled = mutableListOf<Installment>()
    val cancelled = mutableListOf<Long>()
    override fun schedule(installment: Installment) { scheduled.add(installment) }
    override fun cancel(installmentId: Long) { cancelled.add(installmentId) }
}

class UseCasesTest {
    private val repo = FakeRepository()
    private val scheduler = FakeScheduler()
    private val useCases = UseCases.create(repo, scheduler)

    @Test
    fun addTrimsTitleAndSchedulesReminder() = runBlocking {
        val id = useCases.add("  قسط وام  ", 1_000_000, 20_000)
        val saved = repo.getById(id)
        assertNotNull(saved)
        assertEquals("قسط وام", saved!!.title)
        assertEquals(1, scheduler.scheduled.size)
        assertEquals(id, scheduler.scheduled[0].id)
    }

    @Test
    fun unpaidListIsSortedByDueDate() = runBlocking {
        useCases.add("c", 1, 30)
        useCases.add("a", 1, 10)
        useCases.add("b", 1, 20)
        val titles = useCases.observe.unpaid().first().map { it.title }
        assertEquals(listOf("a", "b", "c"), titles)
    }

    @Test
    fun oneTapPaymentMovesItemToHistoryAndCancelsReminder() = runBlocking {
        val id = useCases.add("x", 5, 100)
        useCases.recordPayment(id, 98)
        assertTrue(useCases.observe.unpaid().first().isEmpty())
        val history = useCases.observe.paid().first()
        assertEquals(1, history.size)
        assertEquals(98L, history[0].paidEpochDay)
        assertTrue(scheduler.cancelled.contains(id))
    }

    @Test
    fun paymentDateCanBeEdited() = runBlocking {
        val id = useCases.add("x", 5, 100)
        useCases.recordPayment(id, 98)
        useCases.recordPayment(id, 95)
        assertEquals(95L, repo.getById(id)!!.paidEpochDay)
    }

    @Test
    fun historyIsSortedByPaymentDateDescending() = runBlocking {
        val a = useCases.add("a", 1, 100)
        val b = useCases.add("b", 1, 100)
        useCases.recordPayment(a, 90)
        useCases.recordPayment(b, 95)
        assertEquals(listOf("b", "a"), useCases.observe.paid().first().map { it.title })
    }

    @Test
    fun undoPaymentRestoresInstallmentAndReschedules() = runBlocking {
        val id = useCases.add("x", 5, 100)
        repo.markReminderFired(id)
        useCases.recordPayment(id, 99)
        scheduler.scheduled.clear()
        useCases.undoPayment(id)
        val restored = repo.getById(id)!!
        assertNull(restored.paidEpochDay)
        assertFalse(restored.reminderFired)
        assertEquals(1, scheduler.scheduled.size)
    }

    @Test
    fun changingDueDateResetsReminderFlag() = runBlocking {
        val id = useCases.add("x", 5, 100)
        repo.markReminderFired(id)
        useCases.update(id, "x2", 7, 120)
        val updated = repo.getById(id)!!
        assertEquals("x2", updated.title)
        assertEquals(7L, updated.amount)
        assertEquals(120L, updated.dueEpochDay)
        assertFalse(updated.reminderFired)
    }

    @Test
    fun editingWithoutChangingDueDateKeepsReminderFlag() = runBlocking {
        val id = useCases.add("x", 5, 100)
        repo.markReminderFired(id)
        useCases.update(id, "renamed", 5, 100)
        assertTrue(repo.getById(id)!!.reminderFired)
    }

    @Test
    fun editingPaidInstallmentKeepsItPaid() = runBlocking {
        val id = useCases.add("x", 5, 100)
        useCases.recordPayment(id, 99)
        useCases.update(id, "y", 6, 101)
        assertEquals(99L, repo.getById(id)!!.paidEpochDay)
    }

    @Test
    fun deleteCancelsReminderAndRemovesRow() = runBlocking {
        val id = useCases.add("x", 5, 100)
        useCases.delete(id)
        assertNull(repo.getById(id))
        assertTrue(scheduler.cancelled.contains(id))
    }

    @Test
    fun rescheduleAllOnlyTouchesUnpaidAndUnfired() = runBlocking {
        val a = useCases.add("a", 1, 100)
        val b = useCases.add("b", 1, 100)
        val c = useCases.add("c", 1, 100)
        useCases.recordPayment(b, 99)
        repo.markReminderFired(c)
        scheduler.scheduled.clear()
        useCases.rescheduleAll()
        assertEquals(listOf(a), scheduler.scheduled.map { it.id })
    }

    @Test
    fun prepareReminderSkipsPaidMissingAndAlreadyFired() = runBlocking {
        val a = useCases.add("a", 1, 100)
        val b = useCases.add("b", 1, 100)
        val c = useCases.add("c", 1, 100)
        useCases.recordPayment(b, 99)
        repo.markReminderFired(c)
        assertNotNull(useCases.prepareReminder(a))
        assertNull(useCases.prepareReminder(b))
        assertNull(useCases.prepareReminder(c))
        assertNull(useCases.prepareReminder(999))
        useCases.markReminderFired(a)
        assertNull(useCases.prepareReminder(a))
    }
}
