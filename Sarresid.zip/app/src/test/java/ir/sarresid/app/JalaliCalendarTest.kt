package ir.sarresid.app

import ir.sarresid.app.core.JalaliCalendar
import ir.sarresid.app.core.JalaliDate
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class JalaliCalendarTest {

    private fun g(y: Int, m: Int, d: Int): Long = LocalDate.of(y, m, d).toEpochDay()

    @Test
    fun knownGregorianToJalaliConversions() {
        assertEquals(JalaliDate(1348, 10, 11), JalaliCalendar.fromEpochDay(g(1970, 1, 1)))
        assertEquals(JalaliDate(1378, 10, 11), JalaliCalendar.fromEpochDay(g(2000, 1, 1)))
        assertEquals(JalaliDate(1399, 1, 1), JalaliCalendar.fromEpochDay(g(2020, 3, 20)))
        assertEquals(JalaliDate(1400, 1, 1), JalaliCalendar.fromEpochDay(g(2021, 3, 21)))
        assertEquals(JalaliDate(1401, 1, 1), JalaliCalendar.fromEpochDay(g(2022, 3, 21)))
        assertEquals(JalaliDate(1402, 1, 1), JalaliCalendar.fromEpochDay(g(2023, 3, 21)))
        assertEquals(JalaliDate(1403, 1, 1), JalaliCalendar.fromEpochDay(g(2024, 3, 20)))
        assertEquals(JalaliDate(1404, 1, 1), JalaliCalendar.fromEpochDay(g(2025, 3, 21)))
        assertEquals(JalaliDate(1405, 1, 1), JalaliCalendar.fromEpochDay(g(2026, 3, 21)))
        assertEquals(JalaliDate(1405, 8, 17), JalaliCalendar.fromEpochDay(g(2026, 11, 8)))
    }

    @Test
    fun leapYearEndOfEsfand() {
        // 1399 and 1403 are leap years: Esfand has 30 days.
        assertEquals(JalaliDate(1399, 12, 30), JalaliCalendar.fromEpochDay(g(2021, 3, 20)))
        assertEquals(JalaliDate(1403, 12, 30), JalaliCalendar.fromEpochDay(g(2025, 3, 20)))
        // 1404 is not: Esfand has 29 days.
        assertEquals(JalaliDate(1404, 12, 29), JalaliCalendar.fromEpochDay(g(2026, 3, 20)))
    }

    @Test
    fun jalaliToEpochDay() {
        assertEquals(g(2026, 3, 21), JalaliCalendar.toEpochDay(1405, 1, 1))
        assertEquals(g(2026, 11, 8), JalaliCalendar.toEpochDay(1405, 8, 17))
        assertEquals(g(2025, 3, 20), JalaliCalendar.toEpochDay(1403, 12, 30))
    }

    @Test
    fun knownLeapYears() {
        // 33-year cycle pattern: gaps of 4 years, with a 5-year gap once per cycle (1403 -> 1408, 1436 -> 1441, ...).
        val leap = listOf(
            1383, 1387, 1391, 1395, 1399, 1403, 1408, 1412, 1416, 1420, 1424, 1428, 1432, 1436,
            1441, 1445, 1449, 1453, 1457, 1461, 1465, 1469, 1474, 1478
        )
        for (y in 1380..1480) {
            assertEquals("year $y", leap.contains(y), JalaliCalendar.isLeapYear(y))
        }
    }

    @Test
    fun monthLengths() {
        for (m in 1..6) assertEquals(31, JalaliCalendar.daysInMonth(1405, m))
        for (m in 7..11) assertEquals(30, JalaliCalendar.daysInMonth(1405, m))
        assertEquals(29, JalaliCalendar.daysInMonth(1405, 12))
        assertEquals(30, JalaliCalendar.daysInMonth(1403, 12))
    }

    @Test
    fun roundTripOverWholeSupportedRange() {
        val start = JalaliCalendar.toEpochDay(JalaliCalendar.MIN_YEAR, 1, 1)
        val end = JalaliCalendar.toEpochDay(JalaliCalendar.MAX_YEAR, 12, 29)
        var day = start
        var previous: JalaliDate? = null
        while (day <= end) {
            val j = JalaliCalendar.fromEpochDay(day)
            assertTrue("invalid $j for epochDay $day", JalaliCalendar.isValid(j.year, j.month, j.day))
            assertEquals("round trip for $j", day, JalaliCalendar.toEpochDay(j))
            if (previous != null) {
                assertTrue("not strictly increasing: $previous -> $j", j > previous)
            }
            previous = j
            day++
        }
    }

    @Test
    fun yearLengthsAre365Or366AndMatchLeapFlag() {
        for (y in 1380..1500) {
            val len = JalaliCalendar.toEpochDay(y + 1, 1, 1) - JalaliCalendar.toEpochDay(y, 1, 1)
            assertEquals("year $y", if (JalaliCalendar.isLeapYear(y)) 366L else 365L, len)
        }
    }

    @Test
    fun weekdayIndexStartsOnSaturday() {
        assertEquals(0, JalaliCalendar.dayOfWeekIndex(g(2026, 11, 7))) // Saturday
        assertEquals(1, JalaliCalendar.dayOfWeekIndex(g(2026, 11, 8))) // Sunday
        assertEquals(6, JalaliCalendar.dayOfWeekIndex(g(2026, 11, 13))) // Friday
    }

    @Test
    fun validation() {
        assertTrue(JalaliCalendar.isValid(1403, 12, 30))
        assertFalse(JalaliCalendar.isValid(1404, 12, 30))
        assertFalse(JalaliCalendar.isValid(1405, 7, 31))
        assertFalse(JalaliCalendar.isValid(1405, 13, 1))
        assertFalse(JalaliCalendar.isValid(1405, 1, 0))
    }
}
