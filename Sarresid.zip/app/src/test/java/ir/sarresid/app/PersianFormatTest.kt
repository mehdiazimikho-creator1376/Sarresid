package ir.sarresid.app

import ir.sarresid.app.core.PersianFormat
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PersianFormatTest {

    private fun g(y: Int, m: Int, d: Int): Long = LocalDate.of(y, m, d).toEpochDay()

    @Test
    fun digitsConversion() {
        assertEquals("۰۱۲۳۴۵۶۷۸۹", PersianFormat.digits("0123456789"))
        assertEquals("0123456789", PersianFormat.toLatinDigits("۰۱۲۳۴۵۶۷۸۹"))
        assertEquals("0123456789", PersianFormat.toLatinDigits("٠١٢٣٤٥٦٧٨٩"))
    }

    @Test
    fun amountFormatting() {
        assertEquals("۰", PersianFormat.amount(0))
        assertEquals("۹۹۹", PersianFormat.amount(999))
        assertEquals("۱٬۰۰۰", PersianFormat.amount(1000))
        assertEquals("۱٬۲۵۰٬۰۰۰", PersianFormat.amount(1250000))
        assertEquals("۱۲٬۳۴۵٬۶۷۸٬۹۰۱", PersianFormat.amount(12345678901))
    }

    @Test
    fun amountParsing() {
        assertEquals(1250000L, PersianFormat.parseAmount("1250000"))
        assertEquals(1250000L, PersianFormat.parseAmount("۱۲۵۰۰۰۰"))
        assertEquals(1250000L, PersianFormat.parseAmount("1,250,000"))
        assertEquals(1250000L, PersianFormat.parseAmount("۱٬۲۵۰٬۰۰۰"))
        assertEquals(1250000L, PersianFormat.parseAmount("۱،۲۵۰،۰۰۰"))
        assertEquals(500L, PersianFormat.parseAmount(" 500 "))
        assertNull(PersianFormat.parseAmount(""))
        assertNull(PersianFormat.parseAmount("0"))
        assertNull(PersianFormat.parseAmount("abc"))
        assertNull(PersianFormat.parseAmount("12a3"))
        assertNull(PersianFormat.parseAmount("12.5"))
        assertNull(PersianFormat.parseAmount("-5"))
        assertNull(PersianFormat.parseAmount("1234567890123456"))
    }

    @Test
    fun dateFormatting() {
        val day = g(2026, 11, 8)
        assertEquals("۱۷ آبان ۱۴۰۵", PersianFormat.date(day))
        assertEquals("یکشنبه ۱۷ آبان ۱۴۰۵", PersianFormat.dateWithWeekday(day))
        assertEquals("۱۴۰۵/۰۸/۱۷", PersianFormat.dateNumeric(day))
        assertEquals("۱ فروردین ۱۴۰۵", PersianFormat.date(g(2026, 3, 21)))
    }

    @Test
    fun relativeDays() {
        assertEquals("امروز", PersianFormat.relativeDays(10, 10))
        assertEquals("فردا", PersianFormat.relativeDays(11, 10))
        assertEquals("دیروز", PersianFormat.relativeDays(9, 10))
        assertEquals("۵ روز دیگر", PersianFormat.relativeDays(15, 10))
        assertEquals("۳ روز گذشته", PersianFormat.relativeDays(7, 10))
    }
}
