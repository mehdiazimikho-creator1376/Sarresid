package ir.sarresid.app

import ir.sarresid.app.domain.model.Installment
import ir.sarresid.app.domain.reminder.ReminderMessages
import ir.sarresid.app.domain.reminder.ReminderPlanner
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReminderPlannerTest {
    // Iran uses a fixed +03:30 offset (no DST since 2022).
    private val zone = ZoneOffset.ofHoursMinutes(3, 30)

    private fun millis(y: Int, m: Int, d: Int, h: Int, min: Int): Long =
        LocalDateTime.of(y, m, d, h, min).atZone(zone).toInstant().toEpochMilli()

    private fun day(y: Int, m: Int, d: Int): Long = LocalDate.of(y, m, d).toEpochDay()

    private fun installment(due: Long, paid: Long? = null, fired: Boolean = false) =
        Installment(id = 1, title = "وام خودرو", amount = 2_500_000, dueEpochDay = due, paidEpochDay = paid, reminderFired = fired)

    @Test
    fun firesAtNineAmTheDayBeforeDue() {
        val now = millis(2026, 11, 8, 1, 29)
        val trigger = ReminderPlanner.triggerAtMillis(installment(day(2026, 11, 20)), now, zone)
        assertEquals(millis(2026, 11, 19, 9, 0), trigger)
    }

    @Test
    fun firesSoonWhenPlannedTimeAlreadyPassedButDueIsStillAhead() {
        val now = millis(2026, 11, 19, 21, 0) // due tomorrow, 09:00 today is gone
        val trigger = ReminderPlanner.triggerAtMillis(installment(day(2026, 11, 20)), now, zone)
        assertEquals(now + ReminderPlanner.IMMEDIATE_DELAY_MILLIS, trigger)
    }

    @Test
    fun firesSoonWhenDueToday() {
        val now = millis(2026, 11, 20, 10, 0)
        val trigger = ReminderPlanner.triggerAtMillis(installment(day(2026, 11, 20)), now, zone)
        assertEquals(now + ReminderPlanner.IMMEDIATE_DELAY_MILLIS, trigger)
    }

    @Test
    fun noReminderWhenOverdue() {
        val now = millis(2026, 11, 21, 8, 0)
        assertNull(ReminderPlanner.triggerAtMillis(installment(day(2026, 11, 20)), now, zone))
    }

    @Test
    fun noReminderWhenPaidOrAlreadyFired() {
        val now = millis(2026, 11, 8, 12, 0)
        val due = day(2026, 11, 20)
        assertNull(ReminderPlanner.triggerAtMillis(installment(due, paid = day(2026, 11, 8)), now, zone))
        assertNull(ReminderPlanner.triggerAtMillis(installment(due, fired = true), now, zone))
    }

    @Test
    fun usesLocalDateAroundMidnight() {
        // 00:30 local on Nov 20 is still Nov 19 in UTC, but the user's "today" is Nov 20.
        val now = millis(2026, 11, 20, 0, 30)
        val trigger = ReminderPlanner.triggerAtMillis(installment(day(2026, 11, 20)), now, zone)
        assertTrue(trigger != null && trigger == now + ReminderPlanner.IMMEDIATE_DELAY_MILLIS)
    }

    @Test
    fun messageTexts() {
        val due = day(2026, 11, 20)
        val i = installment(due)
        assertTrue(ReminderMessages.text(i, due - 1).endsWith("فردا سررسید است"))
        assertTrue(ReminderMessages.text(i, due).endsWith("امروز سررسید است"))
        assertTrue(ReminderMessages.text(i, due - 3).endsWith("۳ روز دیگر سررسید است"))
        assertTrue(ReminderMessages.text(i, due - 1).contains("۲٬۵۰۰٬۰۰۰ تومان"))
    }
}
